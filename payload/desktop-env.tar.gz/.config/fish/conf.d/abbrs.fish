abbr -a h history
abbr -a g 'history | grep -i'
abbr -a l 'ls -lahtr'
